**Version**: YOUR_CHARTING_LIBRARY_VERSION (Execute "TradingView.version()" in the browser console.)
**Device**: YOUR_DEVICE (name and OS version)
**Broswer**: YOUR_BROSWER (name and version)
**Description**:
